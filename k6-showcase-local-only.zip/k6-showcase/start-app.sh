#!/usr/bin/env sh
set -e
cd "$(dirname "$0")/app"
[ -d node_modules ] || npm install
npm run dev

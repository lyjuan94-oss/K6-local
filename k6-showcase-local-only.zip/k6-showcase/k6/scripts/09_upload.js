import http from "k6/http";
import { check, sleep } from "k6";
import { baseUrl } from "../lib/helpers.js";
import { handleSummary } from "../lib/summary.js";

export { handleSummary };

/**
 * Multipart upload demo.
 * (Shows file uploads + payload building)
 */
export const options = {
  vus: 5,
  duration: "20s",
  thresholds: {
    http_req_failed: ["rate<0.01"],
    http_req_duration: ["p(95)<1200"],
  },
};

export default function () {
  const bin = new Uint8Array(128 * 1024); // 128KB
  for (let i = 0; i < bin.length; i++) bin[i] = i % 251;

  const data = {
    file: http.file(bin.buffer, `demo-${__VU}-${__ITER}.bin`, "application/octet-stream"),
  };

  const res = http.post(`${baseUrl()}/api/upload`, data, { tags: { endpoint: "upload" } });
  check(res, {
    "upload 200": (r) => r.status === 200,
    "size matches": (r) => r.json("size") === bin.length,
  });
  sleep(0.2);
}

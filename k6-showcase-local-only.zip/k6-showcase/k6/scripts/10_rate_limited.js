import http from "k6/http";
import { check } from "k6";
import { baseUrl } from "../lib/helpers.js";
import { handleSummary } from "../lib/summary.js";

export { handleSummary };

/**
 * Rate limit demo (429):
 * Configure app with RATE_LIMIT_RPS (default 20).
 * Then run high RPS to see 429s and verify behavior.
 */
export const options = {
  scenarios: {
    limited: {
      executor: "constant-arrival-rate",
      rate: 100,
      timeUnit: "1s",
      duration: "20s",
      preAllocatedVUs: 20,
      maxVUs: 200,
    },
  },
  thresholds: {
    "http_req_duration{endpoint:limited}": ["p(95)<400"],
  },
};

export default function () {
  const res = http.get(`${baseUrl()}/api/limited`, { tags: { endpoint: "limited" } });
  check(res, { "status is 200 or 429": (r) => r.status === 200 || r.status === 429 });
}

import http from "k6/http";
import { check, sleep } from "k6";
import { baseUrl } from "../lib/helpers.js";
import { handleSummary } from "../lib/summary.js";

export { handleSummary };

export const options = {
  vus: 1,
  duration: "10s",
  thresholds: {
    http_req_failed: ["rate<0.01"],           // <1% errors
    http_req_duration: ["p(95)<300"],         // p95 under 300ms (health should be fast)
  },
};

export default function () {
  const res = http.get(`${baseUrl()}/health`, { tags: { endpoint: "health" } });
  check(res, {
    "status 200": (r) => r.status === 200,
    "body.ok true": (r) => r.json("ok") === true,
  });
  sleep(1);
}

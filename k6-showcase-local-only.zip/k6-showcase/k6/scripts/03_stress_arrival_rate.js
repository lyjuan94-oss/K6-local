import http from "k6/http";
import { sleep } from "k6";
import { baseUrl } from "../lib/helpers.js";
import { handleSummary } from "../lib/summary.js";

export { handleSummary };

/**
 * Stress with constant-arrival-rate:
 * - Better for "requests per second" driven tests
 */
export const options = {
  scenarios: {
    stress_rps: {
      executor: "constant-arrival-rate",
      rate: 80,            // 80 iterations per second
      timeUnit: "1s",
      duration: "2m",
      preAllocatedVUs: 50,
      maxVUs: 200,
    },
  },
  thresholds: {
    http_req_failed: ["rate<0.05"], // allow some errors as system saturates
    http_req_duration: ["p(95)<800", "p(99)<1500"],
  },
};

export default function () {
  // Mix of "fast" and "heavy" endpoint to show saturation
  http.get(`${baseUrl()}/health`, { tags: { endpoint: "health" } });
  http.get(`${baseUrl()}/api/cpu?ms=20`, { tags: { endpoint: "cpu" } });
  sleep(0.01);
}

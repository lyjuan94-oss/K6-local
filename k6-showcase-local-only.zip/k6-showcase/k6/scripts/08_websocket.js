import ws from "k6/ws";
import { check, sleep } from "k6";
import { baseUrl } from "../lib/helpers.js";
import { handleSummary } from "../lib/summary.js";

export { handleSummary };

export const options = {
  vus: 5,
  duration: "30s",
  thresholds: {
    ws_connecting: ["p(95)<500"],
  },
};

export default function () {
  const url = baseUrl().replace("http", "ws") + "/ws";

  const res = ws.connect(url, {}, (socket) => {
    socket.on("open", () => {
      socket.send(`hello from vu=${__VU} iter=${__ITER}`);
    });

    socket.on("message", (msg) => {
      // We get welcome + echo + broadcast
      check(msg, { "msg is not empty": (m) => !!m && m.length > 0 });
    });

    socket.setTimeout(() => {
      socket.close();
    }, 2500);
  });

  check(res, { "ws status is 101": (r) => r && r.status === 101 });
  sleep(1);
}

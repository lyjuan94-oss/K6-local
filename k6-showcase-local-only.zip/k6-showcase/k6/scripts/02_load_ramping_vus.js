import http from "k6/http";
import { sleep } from "k6";
import { baseUrl, login, listItems } from "../lib/helpers.js";
import { handleSummary } from "../lib/summary.js";

export { handleSummary };

export const options = {
  scenarios: {
    ramping_vus: {
      executor: "ramping-vus",
      stages: [
        { duration: "30s", target: 10 },
        { duration: "1m", target: 25 },
        { duration: "30s", target: 0 },
      ],
      gracefulRampDown: "10s",
    },
  },
  thresholds: {
    http_req_failed: ["rate<0.02"],
    "http_req_duration{endpoint:health}": ["p(95)<200"],
    "http_req_duration{endpoint:items_list}": ["p(95)<500"],
  },
};

export function setup() {
  return { token: login() };
}

export default function (data) {
  http.get(`${baseUrl()}/health`, { tags: { endpoint: "health" } });
  listItems(data.token).tags = { endpoint: "items_list" };
  sleep(0.3);
}

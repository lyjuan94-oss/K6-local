import http from "k6/http";
import { check, group, sleep } from "k6";
import { login, authHeaders, baseUrl, createItem, listItems } from "../lib/helpers.js";
import { handleSummary } from "../lib/summary.js";

export { handleSummary };

/**
 * End-to-end API workflow demo:
 * - setup() login once
 * - correlation via JWT
 * - groups + tags
 * - CRUD
 */
export const options = {
  scenarios: {
    workflow: {
      executor: "ramping-vus",
      stages: [
        { duration: "20s", target: 5 },
        { duration: "40s", target: 15 },
        { duration: "20s", target: 0 },
      ],
    },
  },
  thresholds: {
    http_req_failed: ["rate<0.02"],
    "http_req_duration{endpoint:items_create}": ["p(95)<800"],
    "http_req_duration{endpoint:items_list}": ["p(95)<600"],
  },
};

export function setup() {
  return { token: login() };
}

export default function (data) {
  group("List items", () => {
    const res = http.get(`${baseUrl()}/api/items?limit=10&offset=0`, {
      headers: authHeaders(data.token),
      tags: { endpoint: "items_list" },
    });

    check(res, {
      "list status 200": (r) => r.status === 200,
      "list has items": (r) => (r.json("items") || []).length >= 1,
    });
  });

  group("Create + Update + Delete", () => {
    const createRes = createItem(data.token, __ITER);
    createRes.tags = { endpoint: "items_create" };

    const id = createRes.json("id");
    check(id, { "created item has id": (v) => !!v });

    const upd = http.put(
      `${baseUrl()}/api/items/${id}`,
      JSON.stringify({ name: `k6-upd-${__VU}-${__ITER}`, value: 123 }),
      { headers: authHeaders(data.token), tags: { endpoint: "items_update" } }
    );
    check(upd, { "update 200": (r) => r.status === 200 });

    const del = http.del(`${baseUrl()}/api/items/${id}`, null, {
      headers: authHeaders(data.token),
      tags: { endpoint: "items_delete" },
    });
    check(del, { "delete 204": (r) => r.status === 204 });
  });

  sleep(0.2);
}

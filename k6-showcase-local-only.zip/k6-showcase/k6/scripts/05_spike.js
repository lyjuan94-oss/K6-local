import http from "k6/http";
import { sleep } from "k6";
import { baseUrl } from "../lib/helpers.js";
import { handleSummary } from "../lib/summary.js";

export { handleSummary };

/**
 * Spike test: jump to high load quickly
 */
export const options = {
  stages: [
    { duration: "10s", target: 5 },
    { duration: "20s", target: 80 },
    { duration: "30s", target: 80 },
    { duration: "20s", target: 5 },
    { duration: "10s", target: 0 },
  ],
  thresholds: {
    http_req_failed: ["rate<0.1"],
  },
};

export default function () {
  http.get(`${baseUrl()}/api/slow?ms=100`, { tags: { endpoint: "slow" } });
  sleep(0.1);
}

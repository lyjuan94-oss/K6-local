import http from "k6/http";
import { sleep } from "k6";
import { baseUrl, login, listItems } from "../lib/helpers.js";
import { handleSummary } from "../lib/summary.js";

export { handleSummary };

/**
 * Soak test: stability over time
 */
export const options = {
  scenarios: {
    soak: {
      executor: "constant-vus",
      vus: 15,
      duration: "10m",
    },
  },
  thresholds: {
    http_req_failed: ["rate<0.01"],
    http_req_duration: ["p(95)<700"],
  },
};

export function setup() {
  return { token: login() };
}

export default function (data) {
  http.get(`${baseUrl()}/api/slow?ms=150`, { tags: { endpoint: "slow" } });
  listItems(data.token);
  sleep(1);
}

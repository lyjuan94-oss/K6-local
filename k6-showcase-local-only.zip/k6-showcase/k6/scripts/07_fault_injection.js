import http from "k6/http";
import { check, sleep } from "k6";
import { baseUrl } from "../lib/helpers.js";
import { handleSummary } from "../lib/summary.js";

export { handleSummary };

/**
 * Negative testing / failure injection:
 * - Force 500s at a controlled rate
 * - Prove that thresholds can *fail the test* when the system violates SLOs
 */
export const options = {
  vus: 10,
  duration: "30s",
  thresholds: {
    http_req_failed: ["rate<0.05"], // intentionally strict; will likely fail
  },
};

export default function () {
  const res = http.get(`${baseUrl()}/api/error?code=500&rate=0.2`, { tags: { endpoint: "forced_500" } });
  check(res, {
    "either 200 or 500": (r) => r.status === 200 || r.status === 500,
  });
  sleep(0.1);
}

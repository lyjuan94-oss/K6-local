#!/usr/bin/env sh
set -e
k6 run k6/scripts/01_smoke.js
k6 run k6/scripts/06_api_workflow_auth_crud.js
k6 run k6/scripts/02_load_ramping_vus.js
k6 run k6/scripts/03_stress_arrival_rate.js
k6 run k6/scripts/08_websocket.js

import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import jwt from "jsonwebtoken";
import multer from "multer";
import { WebSocketServer } from "ws";
import { z } from "zod";

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));

const PORT = process.env.PORT ? Number(process.env.PORT) : 3000;
const JWT_SECRET = process.env.JWT_SECRET || "dev_secret";
const DEFAULT_USER = process.env.DEFAULT_USER || "demo";
const DEFAULT_PASS = process.env.DEFAULT_PASS || "demo";
const RATE_LIMIT_RPS = process.env.RATE_LIMIT_RPS ? Number(process.env.RATE_LIMIT_RPS) : 20;

// -----------------------------
// In-memory store (simple on purpose)
// -----------------------------
let nextId = 1;
const items = new Map();

// Seed some items
for (let i = 0; i < 25; i++) {
  const id = nextId++;
  items.set(id, { id, name: `seed-${id}`, value: Math.floor(Math.random() * 1000), createdAt: Date.now() });
}

// -----------------------------
// Helpers
// -----------------------------
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function authMiddleware(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "missing_token" });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    return next();
  } catch {
    return res.status(401).json({ error: "invalid_token" });
  }
}

// Simple schema validation (helps show 400s in negative tests)
const itemSchema = z.object({
  name: z.string().min(1).max(64),
  value: z.number().int().min(0).max(1_000_000),
});

// -----------------------------
// Baseline
// -----------------------------
app.get("/health", (req, res) => {
  res.json({ ok: true, ts: Date.now() });
});

// -----------------------------
// Auth
// -----------------------------
app.post("/auth/login", (req, res) => {
  const { username, password } = req.body ?? {};
  if (username !== DEFAULT_USER || password !== DEFAULT_PASS) {
    return res.status(401).json({ error: "bad_credentials" });
  }

  const token = jwt.sign({ sub: username, roles: ["demo"] }, JWT_SECRET, { expiresIn: "30m" });
  res.json({ access_token: token, token_type: "Bearer", expires_in: 1800 });
});

// -----------------------------
// CRUD (protected)
// -----------------------------
app.get("/api/items", authMiddleware, (req, res) => {
  const limit = Math.min(Number(req.query.limit ?? 20), 100);
  const offset = Math.max(Number(req.query.offset ?? 0), 0);

  const all = Array.from(items.values()).sort((a, b) => a.id - b.id);
  const page = all.slice(offset, offset + limit);
  res.json({
    total: all.length,
    limit,
    offset,
    items: page,
  });
});

app.post("/api/items", authMiddleware, (req, res) => {
  const parsed = itemSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "validation", details: parsed.error.flatten() });

  const id = nextId++;
  const item = { id, ...parsed.data, createdAt: Date.now() };
  items.set(id, item);
  res.status(201).json(item);
});

app.put("/api/items/:id", authMiddleware, (req, res) => {
  const id = Number(req.params.id);
  if (!items.has(id)) return res.status(404).json({ error: "not_found" });

  const parsed = itemSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "validation", details: parsed.error.flatten() });

  const updated = { ...items.get(id), ...parsed.data, updatedAt: Date.now() };
  items.set(id, updated);
  res.json(updated);
});

app.delete("/api/items/:id", authMiddleware, (req, res) => {
  const id = Number(req.params.id);
  if (!items.has(id)) return res.status(404).json({ error: "not_found" });
  items.delete(id);
  res.status(204).send();
});

// -----------------------------
// Controlled latency (p95/p99 demos)
// -----------------------------
app.get("/api/slow", async (req, res) => {
  const ms = Math.min(Math.max(Number(req.query.ms ?? 250), 0), 5000);
  await sleep(ms);
  res.json({ ok: true, sleptMs: ms });
});

// -----------------------------
// Controlled errors / chaos-ish behavior
// /api/error?code=500&rate=0.2  (20% 500s)
// -----------------------------
app.get("/api/error", (req, res) => {
  const code = Math.min(Math.max(Number(req.query.code ?? 500), 400), 599);
  const rate = Math.min(Math.max(Number(req.query.rate ?? 1.0), 0), 1);

  if (Math.random() < rate) return res.status(code).json({ error: `forced_${code}` });
  return res.json({ ok: true, forced: false });
});

// -----------------------------
// Rate-limited endpoint (429 demos)
// -----------------------------
const limiter = rateLimit({
  windowMs: 1000,
  limit: RATE_LIMIT_RPS,
  standardHeaders: true,
  legacyHeaders: false,
});
app.get("/api/limited", limiter, (req, res) => {
  res.json({ ok: true, note: "If you exceed RATE_LIMIT_RPS you'll see 429s." });
});

// -----------------------------
// CPU burn (server saturation demos)
// /api/cpu?ms=50
// -----------------------------
app.get("/api/cpu", (req, res) => {
  const ms = Math.min(Math.max(Number(req.query.ms ?? 25), 0), 3000);
  const start = Date.now();
  while (Date.now() - start < ms) {
    // busy loop
    Math.sqrt(Math.random() * 1e7);
  }
  res.json({ ok: true, burnedMs: ms });
});

// -----------------------------
// File upload (multipart demos)
// -----------------------------
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024 } });
app.post("/api/upload", upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "missing_file" });

  res.json({
    ok: true,
    filename: req.file.originalname,
    size: req.file.size,
    mimetype: req.file.mimetype,
    checksumHint: `${req.file.size}-${req.file.originalname.length}`, // not a real checksum; just demo metadata
  });
});

// -----------------------------
// Start server + WebSocket
// -----------------------------
const server = app.listen(PORT, () => {
  console.log(`[app] listening on http://localhost:${PORT}`);
});

const wss = new WebSocketServer({ server, path: "/ws" });

function broadcast(msg) {
  const payload = typeof msg === "string" ? msg : JSON.stringify(msg);
  for (const client of wss.clients) {
    if (client.readyState === 1) client.send(payload);
  }
}

wss.on("connection", (ws) => {
  ws.send(JSON.stringify({ type: "welcome", ts: Date.now() }));

  ws.on("message", (data) => {
    // echo back + broadcast
    const text = data.toString();
    ws.send(JSON.stringify({ type: "echo", text, ts: Date.now() }));
    broadcast({ type: "broadcast", text, ts: Date.now() });
  });
});

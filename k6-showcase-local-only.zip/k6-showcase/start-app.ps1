Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Push-Location (Join-Path $PSScriptRoot "app")
if (!(Test-Path "node_modules")) { npm install }
npm run dev
Pop-Location

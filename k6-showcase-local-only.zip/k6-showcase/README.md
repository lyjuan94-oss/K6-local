# K6 Showcase (Simple app + a battery of K6 examples)

This repo is designed to be a **simple but convincing** demo of what k6 can do:
- Smoke, load, stress, spike, soak
- Auth + CRUD workflows (token correlation)
- Thresholds, checks, tags, groups
- Custom metrics (Trend/Rate/Counter), per-endpoint SLOs
- Test data parameterization (CSV/JSON)
- WebSockets
- File upload
- Failure injection / negative testing
- Local run + optional InfluxDB/Grafana for time-series dashboards

> The app is intentionally small but includes endpoints that let you test lots of behaviors.

## 1) Prereqs
- Node.js 20+ (to run the demo app locally)
- k6 installed

Why Node? This repo includes a tiny HTTP/WebSocket API so k6 has something realistic to hit (auth, CRUD, slow endpoints, rate-limit, WS, uploads).

## 2) Run the demo app

### Run locally (no Docker)
From repo root:

```bash
cd app
npm install
npm run dev
```


```bash
cd app
npm install
npm run dev
```

## 3) Quick manual checks
```bash
curl http://localhost:3000/health

# login (default user: demo / demo)
curl -s -X POST http://localhost:3000/auth/login -H "content-type: application/json" -d "{\"username\":\"demo\",\"password\":\"demo\"}"
```

## 4) Run k6 tests

### Use local k6 (if installed)
```bash
k6 run k6/scripts/01_smoke.js
k6 run k6/scripts/02_load_ramping_vus.js
k6 run k6/scripts/06_api_workflow_auth_crud.js
k6 run k6/scripts/08_websocket.js
```

## 5) Optional dashboards
If you want time-series dashboards, point k6 to an InfluxDB you already have (or skip dashboards for the demo).
This repo still generates a machine-readable JSON summary per run at `k6/summary/summary.json`.

## 6) What each endpoint is for

- `GET /health` — baseline + smoke
- `POST /auth/login` — token correlation
- `GET /api/items` / `POST /api/items` / `PUT /api/items/:id` / `DELETE /api/items/:id` — CRUD + data churn
- `GET /api/slow?ms=...` — controlled latency (p50/p95/p99)
- `GET /api/error?code=...&rate=...` — controlled errors (negative tests)
- `POST /api/upload` — multipart upload
- `GET /api/limited` — rate-limited endpoint (429 behavior)
- `GET /api/cpu?ms=...` — CPU burn (server saturation)
- `WS /ws` — WebSocket echo + broadcast

## 7) Environment variables
- `PORT` (default 3000)
- `JWT_SECRET` (default "dev_secret")
- `DEFAULT_USER` (default "demo")
- `DEFAULT_PASS` (default "demo")
- `RATE_LIMIT_RPS` (default 20) — for `/api/limited`

k6 env vars:
- `BASE_URL` (default `http://localhost:3000`)
- `K6_INSECURE_SKIP_TLS_VERIFY` (if needed for https demos)

---

## Suggested demo flow (10–15 min)
1) `01_smoke.js` → show checks + quick thresholds
2) `06_api_workflow_auth_crud.js` → show setup(), correlation, groups/tags
3) `02_load_ramping_vus.js` → show ramping users + SLO thresholds
4) `03_stress_arrival_rate.js` → show constant-arrival-rate & server saturation
5) `08_websocket.js` → show WS support
6) (Optional) `docker compose --profile observability up` + `--out influxdb` → show dashboards
